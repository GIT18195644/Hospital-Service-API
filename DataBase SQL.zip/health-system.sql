-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 08:53 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `Hospital_ID` int(50) NOT NULL,
  `Hospital_Name` varchar(200) NOT NULL,
  `Hospital_Address` varchar(100) NOT NULL,
  `Hospital_City` varchar(100) NOT NULL,
  `Hospital_Phone` char(10) NOT NULL,
  `Hospital_Email` varchar(100) NOT NULL,
  `Hospital_Description` varchar(1000) NOT NULL,
  `Open_Hours` int(2) NOT NULL DEFAULT 24
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`Hospital_ID`, `Hospital_Name`, `Hospital_Address`, `Hospital_City`, `Hospital_Phone`, `Hospital_Email`, `Hospital_Description`, `Open_Hours`) VALUES
(1, 'National Hospital', 'Colombo 00700', 'Colombo', '0112691111', 'nationalhospital.sl@gmail.com', 'General Hospital', 24),
(2, 'Dr. Neville Fernando Teaching Hospital', 'Malabe 10115', 'Malabe', '0112407600', 'neville.fernando@hospital.lk', 'Private Hospital', 24),
(3, 'Durdans Hospital', ' Alfred Place 00300', 'Colombo', '0112140000', 'durdans@srilanka.lk', 'Private Hospital', 24),
(4, 'Nawaloka Hospital Specialist Centre', 'Colombo 02 00200', 'Colombo', '0115577111', 'nawaloka@srilanka.lk', 'Private Hospital', 24),
(5, 'Lanka Hospital', 'Colombo 00200', 'Colombo', '0115744474', 'lanka.hospitals@sltnet.lk', 'Private Hospital', 24);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`Hospital_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `Hospital_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
